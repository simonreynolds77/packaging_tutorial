#!/usr/bin/env python3

def add_one(number):
	return number + 1